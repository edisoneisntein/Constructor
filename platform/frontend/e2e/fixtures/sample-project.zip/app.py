import os


def run(config_path: str):
    token = os.getenv('API_KEY')
    return config_path + str(token)


if __name__ == '__main__':
    run('config.yaml')
